namespace System.Windows.Forms.VisualStyles {
public class TextMetricsCharacterSet : System.Enum, System.IComparable, System.IFormattable, System.IConvertible
{

	// Methods
	public virtual bool Equals(object obj) {}
	public virtual int GetHashCode() {}
	public virtual string ToString() {}
	public virtual string ToString(string format, System.IFormatProvider provider) {}
	public virtual int CompareTo(object target) {}
	public virtual string ToString(System.IFormatProvider provider) {}
	public virtual System.TypeCode GetTypeCode() {}
	public string ToString(string format) {}
	public Type GetType() {}

	// Fields
	public int value__;
	public TextMetricsCharacterSet Ansi;
	public TextMetricsCharacterSet Baltic;
	public TextMetricsCharacterSet ChineseBig5;
	public TextMetricsCharacterSet Default;
	public TextMetricsCharacterSet EastEurope;
	public TextMetricsCharacterSet Gb2312;
	public TextMetricsCharacterSet Greek;
	public TextMetricsCharacterSet Hangul;
	public TextMetricsCharacterSet Mac;
	public TextMetricsCharacterSet Oem;
	public TextMetricsCharacterSet Russian;
	public TextMetricsCharacterSet ShiftJis;
	public TextMetricsCharacterSet Symbol;
	public TextMetricsCharacterSet Turkish;
	public TextMetricsCharacterSet Vietnamese;
	public TextMetricsCharacterSet Johab;
	public TextMetricsCharacterSet Arabic;
	public TextMetricsCharacterSet Hebrew;
	public TextMetricsCharacterSet Thai;
}

}
