namespace System.Web.SessionState {
public interface IReadOnlySessionState : IRequiresSessionState
{
}

}
