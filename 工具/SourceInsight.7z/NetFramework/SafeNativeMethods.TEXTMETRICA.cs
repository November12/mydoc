namespace System.Drawing {
public class TEXTMETRICA : System.ValueType
{

	// Methods
	public virtual int GetHashCode() {}
	public virtual bool Equals(object obj) {}
	public virtual string ToString() {}
	public Type GetType() {}

	// Fields
	public int tmHeight;
	public int tmAscent;
	public int tmDescent;
	public int tmInternalLeading;
	public int tmExternalLeading;
	public int tmAveCharWidth;
	public int tmMaxCharWidth;
	public int tmWeight;
	public int tmOverhang;
	public int tmDigitizedAspectX;
	public int tmDigitizedAspectY;
	public byte tmFirstChar;
	public byte tmLastChar;
	public byte tmDefaultChar;
	public byte tmBreakChar;
	public byte tmItalic;
	public byte tmUnderlined;
	public byte tmStruckOut;
	public byte tmPitchAndFamily;
	public byte tmCharSet;
}

}
