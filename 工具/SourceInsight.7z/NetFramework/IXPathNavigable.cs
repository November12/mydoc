namespace System.Xml.XPath {
public interface IXPathNavigable
{

	// Methods
	public abstract virtual XPathNavigator CreateNavigator() {}
}

}
