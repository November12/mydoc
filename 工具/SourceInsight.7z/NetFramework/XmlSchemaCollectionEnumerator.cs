namespace System.Xml.Schema {
public class XmlSchemaCollectionEnumerator : System.Collections.IEnumerator
{

	// Methods
	public bool MoveNext() {}
	public Type GetType() {}
	public virtual string ToString() {}
	public virtual bool Equals(object obj) {}
	public virtual int GetHashCode() {}

	// Properties
	public XmlSchema Current { get{} }
}

}
