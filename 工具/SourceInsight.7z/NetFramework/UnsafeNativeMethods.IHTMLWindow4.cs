namespace System.Windows.Forms {
public interface IHTMLWindow4
{

	// Methods
	public abstract virtual object CreatePopup(System.Object& reserved) {}
	public abstract virtual object frameElement() {}
}

}
