namespace Microsoft.JScript {
public class Package : AST
{

	// Methods
	public static void JScriptPackage(string rootName, Microsoft.JScript.Vsa.VsaEngine engine) {}
	public Type GetType() {}
	public virtual string ToString() {}
	public virtual bool Equals(object obj) {}
	public virtual int GetHashCode() {}
}

}
