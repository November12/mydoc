namespace Microsoft.JScript {
public interface IVsaFullErrorInfo : Microsoft.Vsa.IVsaError
{

	// Properties
	public int EndLine { get{} }
}

}
