namespace System.Windows.Forms {
public class POINTL
{

	// Constructors
	public POINTL() {}

	// Methods
	public Type GetType() {}
	public virtual string ToString() {}
	public virtual bool Equals(object obj) {}
	public virtual int GetHashCode() {}

	// Fields
	public int x;
	public int y;
}

}
