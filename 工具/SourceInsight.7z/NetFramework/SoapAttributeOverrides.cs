namespace System.Xml.Serialization {
public class SoapAttributeOverrides
{

	// Constructors
	public SoapAttributeOverrides() {}

	// Methods
	public void Add(Type type, SoapAttributes attributes) {}
	public void Add(Type type, string member, SoapAttributes attributes) {}
	public Type GetType() {}
	public virtual string ToString() {}
	public virtual bool Equals(object obj) {}
	public virtual int GetHashCode() {}

	// Properties
	public SoapAttributes Item { get{} }
	public SoapAttributes Item { get{} }
}

}
