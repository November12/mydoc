namespace System.Windows.Forms {
public class DataGridViewAdvancedBorderStyle : System.ICloneable
{

	// Constructors
	public DataGridViewAdvancedBorderStyle() {}

	// Methods
	public virtual bool Equals(object other) {}
	public virtual int GetHashCode() {}
	public virtual string ToString() {}
	public Type GetType() {}

	// Properties
	public DataGridViewAdvancedCellBorderStyle All { get{} set{} }
	public DataGridViewAdvancedCellBorderStyle Bottom { get{} set{} }
	public DataGridViewAdvancedCellBorderStyle Left { get{} set{} }
	public DataGridViewAdvancedCellBorderStyle Right { get{} set{} }
	public DataGridViewAdvancedCellBorderStyle Top { get{} set{} }
}

}
