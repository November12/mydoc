namespace System.Web.Services.Description {
public class HttpOperationBinding : ServiceDescriptionFormatExtension
{

	// Constructors
	public HttpOperationBinding() {}

	// Methods
	public Type GetType() {}
	public virtual string ToString() {}
	public virtual bool Equals(object obj) {}
	public virtual int GetHashCode() {}

	// Properties
	public string Location { get{} set{} }
	public object Parent { get{} }
	public bool Required { get{} set{} }
	public bool Handled { get{} set{} }
}

}
