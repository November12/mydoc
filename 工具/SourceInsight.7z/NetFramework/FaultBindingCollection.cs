namespace System.Web.Services.Description {
public class FaultBindingCollection : ServiceDescriptionBaseCollection, System.Collections.IList, System.Collections.ICollection, System.Collections.IEnumerable
{

	// Methods
	public int Add(FaultBinding bindingOperationFault) {}
	public void Insert(int index, FaultBinding bindingOperationFault) {}
	public int IndexOf(FaultBinding bindingOperationFault) {}
	public bool Contains(FaultBinding bindingOperationFault) {}
	public void Remove(FaultBinding bindingOperationFault) {}
	public void CopyTo(FaultBinding[] array, int index) {}
	public virtual void Clear() {}
	public virtual void RemoveAt(int index) {}
	public virtual System.Collections.IEnumerator GetEnumerator() {}
	public Type GetType() {}
	public virtual string ToString() {}
	public virtual bool Equals(object obj) {}
	public virtual int GetHashCode() {}

	// Properties
	public FaultBinding Item { get{} set{} }
	public FaultBinding Item { get{} }
	public int Capacity { get{} set{} }
	public int Count { get{} }
}

}
