namespace System.ServiceProcess {
public class WTSSESSION_NOTIFICATION
{

	// Constructors
	public WTSSESSION_NOTIFICATION() {}

	// Methods
	public Type GetType() {}
	public virtual string ToString() {}
	public virtual bool Equals(object obj) {}
	public virtual int GetHashCode() {}

	// Fields
	public int size;
	public int sessionId;
}

}
