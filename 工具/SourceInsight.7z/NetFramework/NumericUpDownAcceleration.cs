namespace System.Windows.Forms {
public class NumericUpDownAcceleration
{

	// Constructors
	public NumericUpDownAcceleration(int seconds, decimal increment) {}

	// Methods
	public Type GetType() {}
	public virtual string ToString() {}
	public virtual bool Equals(object obj) {}
	public virtual int GetHashCode() {}

	// Properties
	public int Seconds { get{} set{} }
	public decimal Increment { get{} set{} }
}

}
