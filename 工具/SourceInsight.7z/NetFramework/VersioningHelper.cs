namespace System.Runtime.Versioning {
public class VersioningHelper
{

	// Methods
	public static string MakeVersionSafeName(string name, ResourceScope from, ResourceScope to) {}
	public static string MakeVersionSafeName(string name, ResourceScope from, ResourceScope to, Type type) {}
	public Type GetType() {}
	public virtual string ToString() {}
	public virtual bool Equals(object obj) {}
	public virtual int GetHashCode() {}
}

}
