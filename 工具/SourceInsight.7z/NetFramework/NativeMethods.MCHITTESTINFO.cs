namespace System.Windows.Forms {
public class MCHITTESTINFO
{

	// Constructors
	public MCHITTESTINFO() {}

	// Methods
	public Type GetType() {}
	public virtual string ToString() {}
	public virtual bool Equals(object obj) {}
	public virtual int GetHashCode() {}

	// Fields
	public int cbSize;
	public int pt_x;
	public int pt_y;
	public int uHit;
	public short st_wYear;
	public short st_wMonth;
	public short st_wDayOfWeek;
	public short st_wDay;
	public short st_wHour;
	public short st_wMinute;
	public short st_wSecond;
	public short st_wMilliseconds;
}

}
