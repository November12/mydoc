namespace System.Management {
public class ManagementDateTimeConverter
{

	// Methods
	public static System.DateTime ToDateTime(string dmtfDate) {}
	public static string ToDmtfDateTime(System.DateTime date) {}
	public static System.TimeSpan ToTimeSpan(string dmtfTimespan) {}
	public static string ToDmtfTimeInterval(System.TimeSpan timespan) {}
	public Type GetType() {}
	public virtual string ToString() {}
	public virtual bool Equals(object obj) {}
	public virtual int GetHashCode() {}
}

}
