namespace System.Xml.Xsl.Runtime {
public class UnionIterator : System.ValueType
{

	// Methods
	public void Create(XmlQueryRuntime runtime) {}
	public SetIteratorResult MoveNext(System.Xml.XPath.XPathNavigator nestedNavigator) {}
	public virtual int GetHashCode() {}
	public virtual bool Equals(object obj) {}
	public virtual string ToString() {}
	public Type GetType() {}

	// Properties
	public System.Xml.XPath.XPathNavigator Current { get{} }
}

}
