namespace System.Windows.Forms {
public class value_tagELEMDESC : System.ValueType
{

	// Methods
	public virtual int GetHashCode() {}
	public virtual bool Equals(object obj) {}
	public virtual string ToString() {}
	public Type GetType() {}

	// Fields
	public tagTYPEDESC tdesc;
	public tagPARAMDESC paramdesc;
}

}
