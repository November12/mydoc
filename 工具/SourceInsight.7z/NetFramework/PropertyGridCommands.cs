namespace System.Windows.Forms.PropertyGridInternal {
public class PropertyGridCommands
{

	// Constructors
	public PropertyGridCommands() {}

	// Methods
	public Type GetType() {}
	public virtual string ToString() {}
	public virtual bool Equals(object obj) {}
	public virtual int GetHashCode() {}

	// Fields
	public System.ComponentModel.Design.CommandID Reset;
	public System.ComponentModel.Design.CommandID Description;
	public System.ComponentModel.Design.CommandID Hide;
	public System.ComponentModel.Design.CommandID Commands;
}

}
