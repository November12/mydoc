namespace System.Windows.Forms {
public class tagELEMDESC
{

	// Constructors
	public tagELEMDESC() {}

	// Methods
	public Type GetType() {}
	public virtual string ToString() {}
	public virtual bool Equals(object obj) {}
	public virtual int GetHashCode() {}

	// Fields
	public tagTYPEDESC tdesc;
	public tagPARAMDESC paramdesc;
}

}
