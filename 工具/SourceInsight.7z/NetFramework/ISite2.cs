namespace Microsoft.JScript {
public interface ISite2
{

	// Methods
	public abstract virtual object[] GetParentChain(object obj) {}
}

}
