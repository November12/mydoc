namespace System.Xml.Schema {
public class XmlSchemaObjectEnumerator : System.Collections.IEnumerator
{

	// Methods
	public void Reset() {}
	public bool MoveNext() {}
	public Type GetType() {}
	public virtual string ToString() {}
	public virtual bool Equals(object obj) {}
	public virtual int GetHashCode() {}

	// Properties
	public XmlSchemaObject Current { get{} }
}

}
