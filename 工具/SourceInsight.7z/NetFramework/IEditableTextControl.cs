namespace System.Web.UI {
public interface IEditableTextControl : ITextControl
{

	// Events
	public event System.EventHandler TextChanged;
}

}
