namespace System.Windows.Forms {
public class Ole
{

	// Constructors
	public Ole() {}

	// Methods
	public Type GetType() {}
	public virtual string ToString() {}
	public virtual bool Equals(object obj) {}
	public virtual int GetHashCode() {}

	// Fields
	public int PICTYPE_UNINITIALIZED;
	public int PICTYPE_NONE;
	public int PICTYPE_BITMAP;
	public int PICTYPE_METAFILE;
	public int PICTYPE_ICON;
	public int PICTYPE_ENHMETAFILE;
	public int STATFLAG_DEFAULT;
	public int STATFLAG_NONAME;
}

}
