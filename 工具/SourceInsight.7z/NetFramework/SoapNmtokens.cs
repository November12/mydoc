namespace System.Runtime.Remoting.Metadata.W3cXsd2001 {
public class SoapNmtokens : ISoapXsd
{

	// Constructors
	public SoapNmtokens() {}
	public SoapNmtokens(string value) {}

	// Methods
	public virtual string GetXsdType() {}
	public virtual string ToString() {}
	public static SoapNmtokens Parse(string value) {}
	public Type GetType() {}
	public virtual bool Equals(object obj) {}
	public virtual int GetHashCode() {}

	// Properties
	public string XsdType { get{} }
	public string Value { get{} set{} }
}

}
