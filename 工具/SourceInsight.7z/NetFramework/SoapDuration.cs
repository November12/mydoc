namespace System.Runtime.Remoting.Metadata.W3cXsd2001 {
public class SoapDuration
{

	// Constructors
	public SoapDuration() {}

	// Methods
	public static string ToString(System.TimeSpan timeSpan) {}
	public static System.TimeSpan Parse(string value) {}
	public Type GetType() {}
	public virtual string ToString() {}
	public virtual bool Equals(object obj) {}
	public virtual int GetHashCode() {}

	// Properties
	public string XsdType { get{} }
}

}
