namespace System.Windows.Forms {
public class TOOLTIPTEXTA
{

	// Constructors
	public TOOLTIPTEXTA() {}

	// Methods
	public Type GetType() {}
	public virtual string ToString() {}
	public virtual bool Equals(object obj) {}
	public virtual int GetHashCode() {}

	// Fields
	public NMHDR hdr;
	public string lpszText;
	public string szText;
	public System.IntPtr hinst;
	public int uFlags;
}

}
