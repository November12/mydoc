namespace System.Windows.Forms {
public class tagIDLDESC : System.ValueType
{

	// Methods
	public virtual int GetHashCode() {}
	public virtual bool Equals(object obj) {}
	public virtual string ToString() {}
	public Type GetType() {}

	// Fields
	public int dwReserved;
	public short wIDLFlags;
}

}
