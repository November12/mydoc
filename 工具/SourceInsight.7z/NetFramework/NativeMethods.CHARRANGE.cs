namespace System.Design {
public class CHARRANGE
{

	// Constructors
	public CHARRANGE() {}

	// Methods
	public Type GetType() {}
	public virtual string ToString() {}
	public virtual bool Equals(object obj) {}
	public virtual int GetHashCode() {}

	// Fields
	public int cpMin;
	public int cpMax;
}

}
