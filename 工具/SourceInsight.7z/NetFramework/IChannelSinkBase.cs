namespace System.Runtime.Remoting.Channels {
public interface IChannelSinkBase
{

	// Properties
	public System.Collections.IDictionary Properties { get{} }
}

}
