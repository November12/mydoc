namespace Microsoft.Aspnet.Snapin {
public class FORMATETC : System.ValueType
{

	// Methods
	public virtual int GetHashCode() {}
	public virtual bool Equals(object obj) {}
	public virtual string ToString() {}
	public Type GetType() {}
}

}
