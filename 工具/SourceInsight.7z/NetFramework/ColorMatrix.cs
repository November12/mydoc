namespace System.Drawing.Imaging {
public class ColorMatrix
{

	// Constructors
	public ColorMatrix() {}
	public ColorMatrix(float[][] newColorMatrix) {}

	// Methods
	public Type GetType() {}
	public virtual string ToString() {}
	public virtual bool Equals(object obj) {}
	public virtual int GetHashCode() {}

	// Properties
	public float Matrix00 { get{} set{} }
	public float Matrix01 { get{} set{} }
	public float Matrix02 { get{} set{} }
	public float Matrix03 { get{} set{} }
	public float Matrix04 { get{} set{} }
	public float Matrix10 { get{} set{} }
	public float Matrix11 { get{} set{} }
	public float Matrix12 { get{} set{} }
	public float Matrix13 { get{} set{} }
	public float Matrix14 { get{} set{} }
	public float Matrix20 { get{} set{} }
	public float Matrix21 { get{} set{} }
	public float Matrix22 { get{} set{} }
	public float Matrix23 { get{} set{} }
	public float Matrix24 { get{} set{} }
	public float Matrix30 { get{} set{} }
	public float Matrix31 { get{} set{} }
	public float Matrix32 { get{} set{} }
	public float Matrix33 { get{} set{} }
	public float Matrix34 { get{} set{} }
	public float Matrix40 { get{} set{} }
	public float Matrix41 { get{} set{} }
	public float Matrix42 { get{} set{} }
	public float Matrix43 { get{} set{} }
	public float Matrix44 { get{} set{} }
	public float Item { get{} set{} }
}

}
