vim.pdf   我写的笔记和收罗的一些资料
vim.zip  vim的一些插件，解压后放到用户主目录的.vim目录下（我的是/home/chen/.vim）
vimrc   vim的配置文件，放到用户主目录下（我的/home/chen），并改名为".vimrc"。该文件后部有常用快捷键（F1~F2)的定义。

注：以上在ubuntu7.04下使用成功。
